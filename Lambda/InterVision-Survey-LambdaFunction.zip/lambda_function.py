import json
import datetime
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    
    try:
        logger.info("received event")
        logger.info(json.dumps(event))
        customer_id = event['Details']['Parameters']['contactID']
        customer_feedback = event['Details']['Parameters']['customerFeedback']
        agent = event['Details']['Parameters']['Agent']
        
        notification = "Contact ID: {0} \n Rating: {1},\n Agent: {2}".format(customer_id,customer_feedback,agent)
        
        logger.info("Notification created")
        
        client = boto3.client('sns')
        response = client.publish (TargetArn = "arn:aws:sns:us-east-1:039765606255:InterVision",
            Message = json.dumps({'default': notification}),
            MessageStructure ="json"
        )
        
        logger.info("published notification")
        
        return {
            'statusCode': 200,
            'body': json.dumps(response)
        }
    except Exception as e:
        # Log the specific exception
        logger.error("An error occurred: %s", str(e))
        return {
            'statusCode': 500,
            'body': f'An error has occurred: {str(e)}'
        }
    
    # imma