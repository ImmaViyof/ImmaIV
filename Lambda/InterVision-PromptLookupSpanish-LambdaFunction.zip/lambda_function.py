import json
import datetime
import boto3
import logging

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    # Fetch all records from DynamoDB
    table = dynamodb.Table('InterVision-PromptlookupSpanishTable')
    response = table.scan()
    
    # Extract and transform the data
    items = response.get('Items', [])
    result = {item['PromptId']: item['PromptText'] for item in items}
    
    # Return the result as JSON
    return result