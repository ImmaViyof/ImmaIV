import json
import datetime
import boto3
import logging

dynamodb = boto3.resource('dynamodb')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    
    # Fetch all records from DynamoDB
    table = dynamodb.Table('InterVision-HolidayTable')
    response = table.scan()
    
    logger.info("Received response: %s", json.dumps(response))
    
    # Extract and transform the data
    holidays = response.get('Items', [])
    
    logger.info("Received response : %s", json.dumps(holidays))
    
    # Get the current date in MM-DD format
    today = datetime.datetime.now().strftime("%m-%d")
    
    isHoliday = False
    messageToReadToCustomer = ""
    
    # Check if today is a holiday
    for holiday in holidays:
        if holiday["Date"] == today:
            isHoliday = True
            messageToReadToCustomer = holiday["Description"]
    
    # Return the result in a format Amazon Connect can interpret
    return {
        "isHoliday": isHoliday,
        "message": messageToReadToCustomer
    }
